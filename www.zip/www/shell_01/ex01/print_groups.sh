#!/bin/bash
id $FT_USER -Gn | tr " " "," | tr -d "\n"
