/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   MAIN_06.C                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pdavi-al <pdavi-al@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/03/18 16:37:24 by pdavi-al          #+#    #+#             */
/*   Updated: 2023/03/18 16:37:32 by pdavi-al         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int	ft_is_prime(int nb);

int	main(void)
{
	printf("%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n",
			ft_is_prime(-1) == 0 ? "OK" : "Fail",
			ft_is_prime(-3) == 0 ? "OK" : "Fail",
			ft_is_prime(0) == 0 ? "OK" : "Fail",
			ft_is_prime(1) == 0 ? "OK" : "Fail",
			ft_is_prime(2) == 1 ? "OK" : "Fail",
			ft_is_prime(3) == 1 ? "OK" : "Fail",
			ft_is_prime(4) == 0 ? "OK" : "Fail",
			ft_is_prime(5) == 1 ? "OK" : "Fail",
			ft_is_prime(6) == 0 ? "OK" : "Fail",
			ft_is_prime(7) == 1 ? "OK" : "Fail",
			ft_is_prime(10) == 0 ? "OK" : "Fail",
			ft_is_prime(11) == 1 ? "OK" : "Fail",
			ft_is_prime(13) == 1 ? "OK" : "Fail",
			ft_is_prime(19) == 1 ? "OK" : "Fail",
			ft_is_prime(20) == 0 ? "OK" : "Fail");
}
