/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main_01.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pdavi-al <pdavi-al@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/03/18 03:14:43 by pdavi-al          #+#    #+#             */
/*   Updated: 2023/03/23 12:10:02 by pdavi-al         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <stdlib.h>

int	*ft_range(int min, int max);

int	main(void)
{
	int	*range;
	int	i;

	i = 0;
	range = ft_range(-3, 2);
	printf("ft_range(-3, 2)\nesperado:  -3 -2 -1 0 1\nresultado: ");
	while (i < 5)
		printf("%d ", range[i++]);
	printf("\n");
	i = 0;
	range = ft_range(3, 5);
	printf("\nft_range(3, 5)\nesperado:  3 4\nresultado: ");
	while (i < 2)
		printf("%d ", range[i++]);
	printf("\n");
	i = 0;
	range = ft_range(5, 2);
	printf("\nft_range(5, 2)\nesperado:  (nil)\nresultado: ");
	printf("%p", range);
	printf("\n");
}
