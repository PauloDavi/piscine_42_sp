/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main_05.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pdavi-al <pdavi-al@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/03/18 03:14:43 by pdavi-al          #+#    #+#             */
/*   Updated: 2023/03/23 12:08:34 by pdavi-al         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

char	**ft_split(char *str, char *charset);

int	main(void)
{
	char str[] = "  ornitorinco ,batata frita ,piscina  dasdasdasd";
	char charset[] = " ,";
	char **strs = ft_split(str, charset);

	while (*strs != NULL)
		printf("%s$\n", *strs++);
}
