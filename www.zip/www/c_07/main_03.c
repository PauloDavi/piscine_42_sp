/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main_03.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pdavi-al <pdavi-al@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/03/23 05:00:03 by pdavi-al          #+#    #+#             */
/*   Updated: 2023/03/23 13:00:08 by pdavi-al         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <stdlib.h>

char	*ft_strjoin(int size, char **strs, char *sep);

int		main(void)
{
	char *str[] = {
		"ViW36klTQitswxMiZEl4xVdoJ",
		"mUAKkQcwDKfkVKSHwBavOvn4z4MS0YTxCkW48",
		"j6o9MNOC2tjuQNu",
		"954tewr3",
		"LgOXyg0Ygpq45QYD9ih0S3tsjbqRlNWnJ",
		"GE64dc4FWbaNu2FeNQBY4DJs4XQ0a",
		"OUf2YL1VKM9lms7vnkZhTDgsMHMmJQJ7XdzwZ18kAQ",
		"i8tl3Yuzp4RBgvF",
		"IdkhHNfbBiqgTX1LKDp4xVrb8",
		"2fnEBVEdriJQd2vHdMkFLic9",
		"PwrYFV8ayQPkUIzQQGWhBCBXrhrFCP",
		"migH9BQnVuOtMLa36bphYISfCqX3zv1Uh",
		"L7BmycYOX1w76WPH0j2qNANalG14orUZfuOLpjFAAW",
		"Lwur1L1wUt0vHe",
		"V79Xa7xiGHhjPo0n04",
		"CAfO16J7RhimHTmdx6X5DVcumix7qXGg1FInUDcS2jmnT6Pj1qPr",
		" QQVfVI3HYAcH9W1U4IGShRBq04Nme231wrw5gTnSvPAzxMDM",
		" kqo8j5iZ5b8QhSzkDf4QVoyDHZqWIM",
		" 27ZBuy9aWH5bvu2QlqWOono",
		" mwX8jHbS6IcPiIo8ydQaG1CM7Sbc1",
		" dGI59P8j9XQr4cXD1cza9a0bxgPGmv",
		" 8csF7HRd0cMHFmSrQqmDqI",
		" Ta7sD6GJLTBpETFOF5TZkelvWEl4vZh5gCIROB4",
		" 0vobyfDh7kJcRXB9qzLwyllkb3ia",
		" zEkUNr0qN27KVmHcU8Xq4cGxHyVXnHGAM9WswxM",
		" JknD8GAugzRUyWbAacD08ovpCEJUSLNdCr",
		" xHxqHGzYQhUxvfsI40epLbvPC6Q1VCQH4XSaj",
		" WV",
		" Z",
		" ",
		" KIKnPfE",
		" qRaZc",
		" ote5r9GW0TxaNnEnmfZrOeZul11mpix",
		" 7qXGg1FInUDcS2jmnT6Pj1qPrQQVfVI3HYANoNwYA1cDfPjh0pE86Zg2oimCWdsN",
		" HY4zaB7IBXsC5au2oMdz",
		" PwMdC2M5tdRFEMzd7vORxqvE1gSACv",
		" iR",
		" 3akYiBPqU9L3L566J5Fq9rEH6",
		" cqG",
		" 3GQLfhRumEU3MYcFQQvTwfBChtPGaG886UhNaSfW",
		" UZxMOoW4ibgb1UmnhHogdYcD",
		" yT9d",
		" FG9tZhI2BznNy1bVXP3iKcsXedbj1T7T",
		" CtaeGd0RHBhE",
		" HJQFqaE7",
		" ANl7IBbn2D6Hx9Yi53aHDD5dSGft5Orqj6nJad",
		" UJ0bDYuOlwk6Gps4tLFpOORN",
		" 46j0Vj3PZTB8B52hFQCUOtPDY",
		" usD",
		" ",
		" TJTRzkE5QTtxNj",
		" 4Rcb1auItg4hveN",
		" hiZADE9P6FNhA",
		" ",
		" wThGLKwnY9AFpdPlgWuke2VFw4Ls",
		" rG",
		" wrEKNLIMvT9wJjqKBnEIQJD2zWbW57urYO0KxE",
		" AaQsEN5Zt",
		" Yj8M8klHrDbdSnH0L21N8bkqbG",
		" O61Mimqyc2pjV9WE5XLW",
		" Xoyf4fzsBRi1ToBOWGB6",
		" jCnm4QetPEUDqJJOhVywf41TI1",
		" rYQ8m9uODdDa",
		" ",
		" uE1VF3nP5",
		" re1PgXeWHXbpyeR7DC6YPUpZMhOqtWAIFLBp7",
		" ym7LT8doJ3VRSZWT1W",
		" hv4",
		" HbPYCb1z4D3eONHoJvb9voESmPV",
		" ksibuix7qXGg1FInUDcS2jmnT6Pj"
	};
	char *res_str = ft_strjoin(70, str, "ix7qXGg1FInUDcS2jmnT6Pj1qPrQQVfVI3HYA");
	if (res_str == NULL)
		return (1);
	printf("res: %s\n", res_str);
	free(res_str);
	return (0);
}
