/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main_02.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pdavi-al <pdavi-al@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/03/18 03:14:43 by pdavi-al          #+#    #+#             */
/*   Updated: 2023/03/18 03:54:07 by pdavi-al         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <stdlib.h>

int	ft_ultimate_range(int **range, int min, int max);

int	main(void)
{
	int	*range;
	int	range_size;
	int	i;

	i = 0;
	range_size = ft_ultimate_range(&range, -3, 2);
	printf("ft_ultimate_range(-3, 2)\nesperado:  range=[-3 -2 -1 0 1] size=5\nresultado: range=[");
	while (i < 5)
	{
		printf("%d", range[i++]);
		if (i != 5)
			printf(" ");
	}
	printf("] size=%d\n", range_size);
	i = 0;
	range_size = ft_ultimate_range(&range, 3, 5);
	printf("\nft_ultimate_range(3, 5)\nesperado:  range=[3 4] size=2\nresultado: range=[");
	while (i < 2)
	{
		printf("%d", range[i++]);
		if (i != 2)
			printf(" ");
	}
	printf("] size=%d\n", range_size);
	i = 0;
	range_size = ft_ultimate_range(&range, 5, 2);
	printf("\nft_ultimate_range(5, 2)\nesperado:  range=(nil) size=0\nresultado: range=");
	printf("%p", range);
	printf(" size=%d\n", range_size);
}
