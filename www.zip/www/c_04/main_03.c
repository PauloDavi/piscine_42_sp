/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main_03.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pdavi-al <pdavi-al@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/03/13 15:08:50 by pdavi-al          #+#    #+#             */
/*   Updated: 2023/03/21 00:16:21 by pdavi-al         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int	ft_atoi(char *str);

int	main(void)
{
	printf("Test 00\t\texpected: '23'\t\t\t\tresult: '%i'\n", ft_atoi("\t\n\v\f\r      23"));
	printf("Test 01\t\texpected: '-12341'\t\t\tresult: '%i'\n", ft_atoi("     ------+++++---12341"));
	printf("Test 02\t\texpected: '-123413'\t\t\tresult: '%i'\n", ft_atoi("     ------+++++---123413"));
	printf("Test 03\t\texpected: '2147483647'\t\tresult: '%i'\n", ft_atoi("00000000002147483647"));
	printf("Test 04\t\texpected: '0'\t\t\t\tresult: '%i'\n", ft_atoi("a"));
	printf("Test 05\t\texpected: '100'\t\t\t\tresult: '%i'\n", ft_atoi("   100"));
	printf("Test 06\t\texpected: '0'\t\t\t\tresult: '%i'\n", ft_atoi("d100"));
	printf("Test 07\t\texpected: '0'\t\t\t\tresult: '%i'\n", ft_atoi("0"));
	printf("Test 08\t\texpected: '546'\t\t\t\tresult: '%i'\n", ft_atoi("546:5"));
	printf("Test 09\t\texpected: '-4886'\t\t\tresult: '%i'\n", ft_atoi("-4886"));
	printf("Test 10\t\texpected: '548'\t\t\t\tresult: '%i'\n", ft_atoi("+548"));
	printf("Test 11\t\texpected: '54854'\t\t\tresult: '%i'\n", ft_atoi("054854"));
	printf("Test 12\t\texpected: '74'\t\t\t\tresult: '%i'\n", ft_atoi("000074"));
	printf("Test 13\t\texpected: '-54'\t\t\t\tresult: '%i'\n", ft_atoi("+-54"));
	printf("Test 14\t\texpected: '-1'\t\t\t\tresult: '%i'\n", ft_atoi("-+01"));
	printf("Test 15\t\texpected: '47'\t\t\t\tresult: '%i'\n", ft_atoi("--47"));
	printf("Test 16\t\texpected: '47'\t\t\t\tresult: '%i'\n", ft_atoi("++47"));
	printf("Test 17\t\texpected: '47'\t\t\t\tresult: '%i'\n", ft_atoi("+47+5"));
	printf("Test 18\t\texpected: '-47'\t\t\t\tresult: '%i'\n", ft_atoi("-47-5"));
	printf("Test 19\t\texpected: '475'\t\t\t\tresult: '%i'\n", ft_atoi("\e475"));
	printf("Test 20\t\texpected: '469'\t\t\t\tresult: '%i'\n", ft_atoi("\t\n\r\v\f  469 \n"));
	printf("Test 21\t\texpected: '-2147483648'\t\tresult: '%i'\n", ft_atoi("-2147483648"));
	printf("Test 22\t\texpected: '2147483647'\t\tresult: '%i'\n", ft_atoi("2147483647"));
	printf("Test 23\t\texpected: '0'\t\t\t\tresult: '%i'\n", ft_atoi("\t\n\r\v\fd469 \n"));
	printf("Test 24\t\texpected: '-46'\t\t\t\tresult: '%i'\n", ft_atoi("\n\n\n  -46\b9 \n5d6"));
	printf("Test 25\t\texpected: '0'\t\t\t\tresult: '%i'\n", ft_atoi(""));
}

