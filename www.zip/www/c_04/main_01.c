/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main_01.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pdavi-al <pdavi-al@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/03/14 15:13:12 by pdavi-al          #+#    #+#             */
/*   Updated: 2023/03/14 22:38:14 by pdavi-al         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <string.h>
#include <stdio.h>
#include <unistd.h>

int	ft_putstr(char *str);

int main() {
	ft_putstr("");
	write(1, "--\n", 3);
	ft_putstr("hola!\n");
	char s1[10] = "asdfsfg";
	ft_putstr(s1);
}
