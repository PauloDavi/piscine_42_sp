/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main_00.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pdavi-al <pdavi-al@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/03/14 15:13:34 by pdavi-al          #+#    #+#             */
/*   Updated: 2023/03/14 17:50:04 by pdavi-al         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <string.h>
#include <stdio.h>

int	ft_strlen(char *str);

int	main() {
	printf("len of: '%s' = %i (expected 0)\n", "", ft_strlen(""));
	printf("len of: '%s' = %i (expected 8)\n", "sggdsdsg", ft_strlen("sggdsdsg"));
	printf("len of: '%s' = %i (expected 7)\n", "asdfsfg", ft_strlen("asdfsfg"));
}
