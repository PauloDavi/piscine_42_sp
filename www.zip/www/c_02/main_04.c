/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main_04.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pdavi-al <pdavi-al@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/03/11 02:19:04 by pdavi-al          #+#    #+#             */
/*   Updated: 2023/03/11 13:22:15 by pdavi-al         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int	ft_str_is_lowercase(char *str);

int	main(void)
{
	char	*str;

	str = "";
	printf("String vazia = %i\n", ft_str_is_lowercase(str));
	str = "ornitorrinco";
	printf("String %s = %i\n", str, ft_str_is_lowercase(str));
	str = "ornito rrinco";
	printf("String %s = %i\n", str, ft_str_is_lowercase(str));
	str = "Australopitecos";
	printf("String %s = %i\n", str, ft_str_is_lowercase(str));
}
