/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main_02.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pdavi-al <pdavi-al@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/03/08 10:32:57 by pdavi-al          #+#    #+#             */
/*   Updated: 2023/03/11 13:26:47 by pdavi-al         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int	ft_str_is_alpha(char *str);

int	main(void)
{
	char	*str;

	str = "";
	printf("String empty = %i\n", ft_str_is_alpha(str));
	str = "daSdsAd";
	printf("String %s = %i\n", str, ft_str_is_alpha(str));
	str = "sdAd aSd ad";
	printf("String %s = %i\n", str, ft_str_is_alpha(str));
}
