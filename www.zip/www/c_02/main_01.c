/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main_01.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pdavi-al <pdavi-al@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/03/11 09:13:10 by pdavi-al          #+#    #+#             */
/*   Updated: 2023/03/17 19:20:44 by pdavi-al         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

char	*ft_strncpy(char *dest, char *src, unsigned int n);

int main(void)
{
	char dest[] = "teste antigo";
	char src[] = "novo";

	printf("String de destino antes da ft_strncpy: \"%s\"\n", dest);
	printf("String de destino depois da ft_strncpy copiando apenas 4 caracteres: \"%s\"\n", ft_strncpy(dest, src, 6));
}
