/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main_07.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pdavi-al <pdavi-al@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/03/08 10:32:57 by pdavi-al          #+#    #+#             */
/*   Updated: 2023/03/11 13:26:21 by pdavi-al         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char	*ft_strupcase(char *str);

int	main(void)
{
	char	*str;

	str = malloc(sizeof(char) * 15);
	strcpy(str, "ESSE e um TESTE");
	printf("Before ft_strupcase: %s\n", str);
	ft_strupcase(str);
	printf("After ft_strupcase: %s\n", str);
	free(str);
	return (0);
}
